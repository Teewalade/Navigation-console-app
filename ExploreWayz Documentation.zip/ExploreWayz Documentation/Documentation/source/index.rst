.. smart Travel Documentation documentation master file, created by
   sphinx-quickstart on Sun Dec 31 05:18:32 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to smart Travel Documentation!
======================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


.. contents:: Table of Contents
   :depth: 2

Functions and Usage
===================================

Introduction
------------

This documentation covers the functionalities provided by the functions in the `functions.py` script.
It also covers the functionalities provided by the get_user_input() in the `main.py` script

Get Location Coordinates Function
---------------------------------

The `get_location_coordinates` function accesses the Google Maps API to return the coordinates (latitude and longitude) of a specified place.

Usage
~~~~~

The function takes one argument:

- `place` (str): The location for which coordinates are to be fetched.

Returns
~~~~~~~

A string containing the latitude and longitude in the format "latitude,longitude".

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import get_location_coordinates

    location = "San Francisco"
    coordinates = get_location_coordinates(location)
    print("Coordinates:", coordinates)

Note
~~~~

- If the specified place is not found, the function returns `None`.

---

Log Coordinates Function
------------------------

The `log_coordinates` function logs the coordinates (latitude and longitude) of a place to a text file.

Usage
~~~~~

The function takes three arguments:

- `place` (str): The name of the place.
- `longitude` (str): The longitude of the place.
- `latitude` (str): The latitude of the place.

Returns
~~~~~~~

This function doesn't return any value (`None`).

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import log_coordinates

    place = "San Francisco"
    longitude = "-122.4194"
    latitude = "37.7749"
    log_coordinates(place, longitude, latitude)

Note
~~~~

- This function writes the place name and its coordinates to a text file.
Get Nearby Places Function
--------------------------

The `get_nearby_places` function returns a specific type of place based on coordinates, search query, user rating, and the number of results.

Usage
~~~~~

The function takes four arguments:

- `location` (str): Coordinates (latitude,longitude) of the area.
- `search` (str): Type of place to search for.
- `user_rating` (int/str): Minimum user rating or 'any' for any rating.
- `number_of_output` (int): Number of results to retrieve.

Returns
~~~~~~~

A list of nearby places based on the search criteria.

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import get_nearby_places

    location = "37.7749,-122.4194"
    search = "restaurant"
    user_rating = 4
    number_of_output = 5
    places = get_nearby_places(location, search, user_rating, number_of_output)
    print("Nearby Places:", places)

Note
~~~~

- If the specified search or location is invalid, the function returns `None`.

Display Nearby Places Function
------------------------------

The `display_nearby_places` function displays a list of places, ratings, and addresses based on the provided data.

Usage
~~~~~

The function takes one argument:

- `places` (list): List of places with details.

Returns
~~~~~~~

This function doesn't return any value (`None`).

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import display_nearby_places

    places = [
        {
            'name': 'Restaurant 1',
            'rating': 4.5,
            'vicinity': 'Address 1'
        },
        {
            'name': 'Restaurant 2',
            'rating': 3.8,
            'vicinity': 'Address 2'
        }
    ]
    display_nearby_places(places)

Note
~~~~

- This function prints the places' details to the console.

Weather Check Function
----------------------

The `weather_check` function checks the weather by passing a city and country.

Usage
~~~~~

The function takes two arguments:

- `user_city` (str): City for weather check.
- `user_country` (str): Country for weather check.

Returns
~~~~~~~

A string containing weather information based on the user's location.

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import weather_check

    city = "San Francisco"
    country = "US"
    weather_info = weather_check(city, country)
    print("Weather Information:", weather_info)

Note
~~~~

- If the specified city or country is invalid, the function returns `None`.

Direction Function
------------------

The `direction` function provides directions between two locations based on user input.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

This returns a tuple destination_country , destination_city

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import direction

    direction()

Note
~~~~

- This function interacts with the user to get input for directions.

Get User Input Function
-----------------------

The `get_user_input` function collects user inputs regarding city, country, search query, user rating preference, and the number of results to display.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

A tuple containing user input values for city, country, search query, user rating, and the number of results.

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import get_user_input

    user_input = get_user_input()
    print("User Input:", user_input)

Note
~~~~

- This function interacts with the user to get various input values.

Discover More Places Function
-----------------------------

The `discover_more_places` function helps discover places based on user inputs.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

This function doesn't return any value (`None`).

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import discover_more_places

    discover_more_places()

Note
~~~~

- This function interacts with the user to discover more places.

Discover Places Service Function
--------------------------------

The `discover_places_service` function handles discovering places based on user input and continues the discovery process until the user decides not to discover more.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

This function doesn't return any value (`None`).

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import discover_places_service

    discover_places_service()

Note
~~~~

- This function interacts with the user to discover places.

Push Navigation Services Function
---------------------------------

The `push_navigation_services` function prompts the user about exploring the navigation service.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

A string indicating the user's choice ('Yes' or 'No').

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import push_navigation_services

    choice = push_navigation_services()
    print("User's Choice:", choice)

Note
~~~~

- This function interacts with the user about navigation services.

More Navigation Service Function
---------------------------------

The `more_navigation_service` function asks the user if they want navigation services for other destinations.

Usage
~~~~~

This function doesn't take any arguments interactively. It prompts the user for input.

Returns
~~~~~~~

A string indicating the user's choice ('Yes' or 'No').

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import more_navigation_service

    choice = more_navigation_service()
    print("User's Choice:", choice)

Note
~~~~

- This function interacts with the user about more navigation services.

Navigation Services Function
---------------------------

The `navigation_services` function orchestrates the navigation service by managing the process of discovering new places in a destination. It utilizes user preferences to fetch and display nearby places.

Usage
~~~~~

This function doesn't take any arguments.

Returns
~~~~~~~

This function doesn't return any value; it handles navigation-related tasks based on user input.

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import navigation_services

    navigation_services()
    # The function will interactively manage the navigation services based on user input.

Note
~~~~

- The function continuously prompts the user to discover new or more places in a destination.
- It uses the `get_location_coordinates`, `get_nearby_places`, and `display_nearby_places` functions to fetch and display nearby places based on user input.
- The function also utilizes the `more_navigation_service` function to determine if the user wants navigation services for other destinations.



Clear Console Function
----------------------

The `clear_console` function clears the console screen.

Usage
~~~~~

This function doesn't take any arguments.

Returns
~~~~~~~

This function doesn't return any value (`None`).

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import clear_console

    clear_console()

App Exit Function
-----------------

The `app_exit` function asks the user if they want to exit the application.

Usage
~~~~~

This function doesn't take any arguments.

Returns
~~~~~~~

A string representing the user's choice to exit the application. It returns either 'yes' or 'no'.

Example
~~~~~~~

Here is an example of how to use the function:

.. code-block:: python

    from functions import app_exit

    choice = app_exit()
    if choice == 'yes':
        print("Exiting the application...")
        # Add code to exit the application
    elif choice == 'no':
        print("Continuing with the application...")
        # Add code to continue using the application
    else:
        print("Invalid choice. Please type 'Yes' or 'No'.")

Happy coding!